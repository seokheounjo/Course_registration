package com.example.Course_registration.config;

import com.samskivert.mustache.Mustache;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MustacheConfig {

    @Bean
    public Mustache.Compiler mustacheCompiler(Mustache.TemplateLoader loader) {
        return Mustache.compiler()
                .withLoader(loader)
                .defaultValue("")
                .withHelpers(new MustacheHelpers()); // 사용자 정의 헬퍼 등록
    }
}
