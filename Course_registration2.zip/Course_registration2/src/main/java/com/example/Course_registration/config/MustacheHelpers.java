package com.example.Course_registration.config;

import com.samskivert.mustache.Mustache;
import com.samskivert.mustache.Mustache.Lambda;
import com.samskivert.mustache.Mustache.Fragment;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;

public class MustacheHelpers extends HashMap<String, Lambda> {

    public MustacheHelpers() {
        put("equals", new Lambda() {
            @Override
            public void execute(Fragment frag, Writer out) throws IOException {
                Object[] context = frag.context();
                if (context.length >= 2 && context[0] != null && context[0].equals(context[1])) {
                    frag.execute(out);
                }
            }
        });
    }
}
