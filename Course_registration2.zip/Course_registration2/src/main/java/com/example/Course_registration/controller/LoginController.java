package com.example.Course_registration.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        // src/main/resources/templates/login.mustache 렌더링
        return "login";
    }
}
