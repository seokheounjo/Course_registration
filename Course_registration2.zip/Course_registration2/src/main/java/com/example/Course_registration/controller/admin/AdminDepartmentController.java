// src/main/java/com/example/Course_registration/controller/admin/AdminDepartmentController.java
package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.DepartmentForm;
import com.example.Course_registration.service.admin.AdminDepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/departments")
@RequiredArgsConstructor
public class AdminDepartmentController {

    private final AdminDepartmentService svc;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("title", "학과 목록");
        m.addAttribute("departments", svc.findAll());
        return "admin/department_list";
    }

    @GetMapping("/create")
    public String createForm(Model m) {
        m.addAttribute("title", "학과 등록");
        m.addAttribute("form", new DepartmentForm());
        return "admin/department_form";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute DepartmentForm form) {
        svc.create(form);
        return "redirect:/admin/departments";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        m.addAttribute("title", "학과 수정");
        m.addAttribute("form", svc.findById(id));
        return "admin/department_form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute DepartmentForm form) {
        svc.update(id, form);
        return "redirect:/admin/departments";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        svc.delete(id);
        return "redirect:/admin/departments";
    }
}
