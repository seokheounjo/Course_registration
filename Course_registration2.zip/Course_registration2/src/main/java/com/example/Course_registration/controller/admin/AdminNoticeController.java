package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.NoticeForm;
import com.example.Course_registration.service.admin.AdminNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/notices")
@RequiredArgsConstructor
public class AdminNoticeController {
    private final AdminNoticeService svc;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("notices", svc.findAll());
        return "admin/notice_list";
    }

    @GetMapping("/create")
    public String createForm(Model m) {
        m.addAttribute("form", new NoticeForm());
        return "admin/notice_form";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute NoticeForm form) {
        svc.create(form);
        return "redirect:/admin/notices";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        m.addAttribute("form", svc.findById(id));
        return "admin/notice_form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute NoticeForm form) {
        svc.update(id, form);
        return "redirect:/admin/notices";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        svc.delete(id);
        return "redirect:/admin/notices";
    }
}