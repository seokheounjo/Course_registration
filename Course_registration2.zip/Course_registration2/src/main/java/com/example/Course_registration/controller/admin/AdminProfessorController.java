package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.Option;
import com.example.Course_registration.dto.ProfessorForm;
import com.example.Course_registration.service.admin.AdminDepartmentService;
import com.example.Course_registration.service.admin.AdminProfessorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Controller @RequestMapping("/admin/professors") @RequiredArgsConstructor
public class AdminProfessorController {

    private final AdminProfessorService svc;
    private final AdminDepartmentService deptSvc;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("title","교수 목록");
        m.addAttribute("professors", svc.findAll());
        return "admin/professor_list";
    }

    @GetMapping("/create")
    public String createForm(Model m) {
        m.addAttribute("title","교수 등록");
        m.addAttribute("form", new ProfessorForm());
        m.addAttribute("departments", deptSvc.findAll());
        return "admin/professor_form";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute ProfessorForm f) {
        svc.create(f);
        return "redirect:/admin/professors";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        m.addAttribute("title","교수 수정");
        m.addAttribute("form", svc.findById(id));
        m.addAttribute("departments", deptSvc.findAll());
        return "admin/professor_form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute ProfessorForm f) {
        svc.update(id, f);
        return "redirect:/admin/professors";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        svc.delete(id);
        return "redirect:/admin/professors";
    }
}
