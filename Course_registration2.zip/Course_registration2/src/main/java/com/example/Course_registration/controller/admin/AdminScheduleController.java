package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.ScheduleForm;
import com.example.Course_registration.service.admin.AdminScheduleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/schedules")
public class AdminScheduleController {

    private final AdminScheduleService adminScheduleService;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("schedules", adminScheduleService.findAll());
        return "schedule/list";
    }

    @GetMapping("/create")
    public String createForm(Model m) {
        m.addAttribute("form", new ScheduleForm());
        // 필요하면 과목 옵션도 뷰에 넘기기
        return "schedule/form";
    }

    @PostMapping("/create")
    public String create(@Valid @ModelAttribute("form") ScheduleForm form, BindingResult br) {
        if (br.hasErrors()) return "schedule/form";
        adminScheduleService.create(form);
        return "redirect:/admin/schedules";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        m.addAttribute("form", adminScheduleService.getForm(id));
        return "schedule/form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id,
                         @Valid @ModelAttribute("form") ScheduleForm form,
                         BindingResult br) {
        if (br.hasErrors()) return "schedule/form";
        adminScheduleService.update(id, form);
        return "redirect:/admin/schedules";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        adminScheduleService.delete(id);
        return "redirect:/admin/schedules";
    }
}