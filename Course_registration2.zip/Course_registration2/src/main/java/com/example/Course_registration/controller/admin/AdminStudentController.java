// src/main/java/com/example/Course_registration/controller/admin/AdminStudentController.java
package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.StudentForm;
import com.example.Course_registration.dto.DepartmentForm;
import com.example.Course_registration.entity.department.Department;
import com.example.Course_registration.service.admin.AdminStudentService;
import com.example.Course_registration.service.admin.AdminDepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/students")
@RequiredArgsConstructor
public class AdminStudentController {

    private final AdminStudentService   svc;
    private final AdminDepartmentService deptSvc;

    // 1) 목록
    @GetMapping
    public String list(Model m) {
        m.addAttribute("title", "학생 목록");
        m.addAttribute("students", svc.findAll());
        return "admin/student_list";
    }

    // 2) 등록 폼
    @GetMapping("/create")
    public String createForm(Model m) {
        List<Department> departments = deptSvc.findAll();

        List<Map<String, Object>> deptOptions = departments.stream().map(d -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", d.getId());
            map.put("name", d.getName());
            map.put("selected", false); // 처음엔 선택 없음
            return map;
        }).toList();

        m.addAttribute("form", new StudentForm());
        m.addAttribute("departments", deptOptions);
        return "admin/student_form";
    }

    // 3) 등록 처리
    @PostMapping("/create")
    public String create(@ModelAttribute StudentForm form) {
        svc.create(form);
        return "redirect:/admin/students";
    }

    // 4) 수정 폼
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        StudentForm form = svc.findById(id);
        List<Department> departments = deptSvc.findAll();

        List<Map<String, Object>> deptOptions = departments.stream().map(d -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", d.getId());
            map.put("name", d.getName());
            map.put("selected", d.getId().equals(form.getDepartmentId()));
            return map;
        }).toList();

        m.addAttribute("form", form);
        m.addAttribute("departments", deptOptions);
        return "admin/student_form";
    }

    // 5) 수정 처리
    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id,
                         @ModelAttribute StudentForm form) {
        svc.update(id, form);
        return "redirect:/admin/students";
    }

    // 6) 삭제 처리
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        svc.delete(id);
        return "redirect:/admin/students";
    }
}
