package com.example.Course_registration.controller.admin;

import com.example.Course_registration.dto.Option;
import com.example.Course_registration.dto.SubjectForm;
import com.example.Course_registration.service.admin.AdminSubjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/subjects")
@RequiredArgsConstructor
public class AdminSubjectController {

    private final AdminSubjectService svc;

    // 목록
    @GetMapping
    public String list(Model m) {
        m.addAttribute("subjects", svc.findAll());
        return "admin/subject_list";
    }

    // 생성 폼
    @GetMapping("/create")
    public String createForm(Model m) {
        m.addAttribute("form", new SubjectForm());
        m.addAttribute("professors", svc.listProfessors());
        m.addAttribute("departments", svc.listDepartments());
        return "admin/subject_form";
    }

    // 생성 처리
    @PostMapping("/create")
    public String create(@ModelAttribute SubjectForm form) {
        svc.create(form);
        return "redirect:/admin/subjects";
    }

    // 수정 폼
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model m) {
        SubjectForm form = svc.getById(id);
        m.addAttribute("form", form);

        // 선택된 교수만 selected=true
        List<Option> profOptions = svc.listProfessors();
        profOptions.stream()
                .filter(opt -> opt.getId().equals(form.getDepartmentId()))
                .findFirst()
                .ifPresent(opt -> opt.setSelected(true));
        m.addAttribute("professors", profOptions);

        // 선택된 학과만 selected=true
        List<Option> deptOptions = svc.listDepartments();
        deptOptions.stream()
                .filter(opt -> opt.getId().equals(form.getDepartmentId()))
                .findFirst()
                .ifPresent(opt -> opt.setSelected(true));
        m.addAttribute("departments", deptOptions);

        return "admin/subject_form";
    }

    // 수정 처리
    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute SubjectForm form) {
        svc.update(id, form);
        return "redirect:/admin/subjects";
    }

    // 삭제 처리
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        svc.delete(id);
        return "redirect:/admin/subjects";
    }
}
