package com.example.Course_registration.controller.student;

import com.example.Course_registration.entity.enrollment.Enrollment;
import com.example.Course_registration.service.student.StudentEnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/student/enrollments")
public class StudentEnrollmentController {

    private final StudentEnrollmentService enrollmentService;

    @GetMapping
    public String myEnrollments(@AuthenticationPrincipal User user, Model model) {
        List<Enrollment> enrollments = enrollmentService.findByStudentEmail(user.getUsername());
        model.addAttribute("enrollments", enrollments);
        return "student/enrollment_list";
    }
}
