package com.example.Course_registration.controller.student;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentHomeController {

    @GetMapping("/home")
    public String studentHome(Model model) {
        model.addAttribute("message", "학생 수강신청 홈에 오신 것을 환영합니다.");
        return "student/home";
    }
}
