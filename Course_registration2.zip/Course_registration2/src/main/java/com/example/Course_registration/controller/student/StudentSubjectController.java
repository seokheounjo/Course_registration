package com.example.Course_registration.controller.student;

import com.example.Course_registration.entity.enrollment.Enrollment;
import com.example.Course_registration.entity.student.Student;
import com.example.Course_registration.entity.subject.Subject;
import com.example.Course_registration.service.student.StudentEnrollmentService;
import com.example.Course_registration.service.student.StudentSubjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/student/subjects")
public class StudentSubjectController {

    private final StudentSubjectService subjectService;
    private final StudentEnrollmentService enrollmentService;

    @GetMapping
    public String subjectList(@AuthenticationPrincipal User user, Model model) {
        String email = user.getUsername();
        List<Subject> subjects = subjectService.findAll();
        List<Enrollment> myEnrollments = enrollmentService.findByStudentEmail(email);
        model.addAttribute("subjects", subjects);
        model.addAttribute("enrollments", myEnrollments);
        return "student/subject_list";
    }

    @PostMapping("/enroll/{subjectId}")
    public String enroll(@PathVariable Long subjectId, @AuthenticationPrincipal User user) {
        enrollmentService.enroll(user.getUsername(), subjectId);
        return "redirect:/student/subjects";
    }

    @PostMapping("/cancel/{subjectId}")
    public String cancel(@PathVariable Long subjectId, @AuthenticationPrincipal User user) {
        enrollmentService.cancel(user.getUsername(), subjectId);
        return "redirect:/student/subjects";
    }
}
