// src/main/java/com/example/Course_registration/dto/DepartmentForm.java
package com.example.Course_registration.dto;

import com.example.Course_registration.entity.department.Department;
import lombok.*;

@Getter @Setter @NoArgsConstructor
public class DepartmentForm {
    private Long   id;
    private String name;

    public DepartmentForm(Department d) {
        this.id   = d.getId();
        this.name = d.getName();
    }
}
