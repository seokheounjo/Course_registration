// NoticeForm.java
package com.example.Course_registration.dto;

import com.example.Course_registration.entity.notice.Notice;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class NoticeForm {
    private Long id;
    private String title;
    private String content;

    public NoticeForm(Notice n) {
        this.id = n.getId();
        this.title = n.getTitle();
        this.content = n.getContent();
    }
}