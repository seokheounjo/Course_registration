package com.example.Course_registration.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@AllArgsConstructor
public class Option {
    private Long id;
    private String name;
    private boolean selected; // 선택 상태
}
