package com.example.Course_registration.dto;

import com.example.Course_registration.entity.professor.Professor;
import lombok.*;

@Getter @Setter @NoArgsConstructor
public class ProfessorForm {
    private Long id;
    private String professorCode;
    private String name;
    private Long departmentId;

    public ProfessorForm(Professor p) {
        this.id            = p.getId();
        this.professorCode = p.getProfessorCode();
        this.name          = p.getName();
        this.departmentId  = (p.getDepartment()!=null) ? p.getDepartment().getId() : null;
    }
}
