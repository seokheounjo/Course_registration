package com.example.Course_registration.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ScheduleForm {
    private Long id;

    @NotBlank
    private String dayOfWeek;      // Schedule.dayOfWeek 에 매핑

    @NotBlank
    private String startTime;      // ex) "09:00"

    @NotBlank
    private String endTime;        // ex) "10:30"

    @NotNull
    private Long subjectId;        // Schedule.subject.id 에 매핑
}
