package com.example.Course_registration.dto;

import com.example.Course_registration.entity.student.Student;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class StudentForm {
    private Long   id;
    private String studentNumber;
    private String name;
    private String email;
    private String phone;
    private Integer grade;
    private Long   departmentId;

    private String password;  // ← 로그인용 비밀번호

    public StudentForm(Student s) {
        this.id            = s.getId();
        this.studentNumber = s.getStudentNumber();
        this.name          = s.getName();
        this.email         = s.getEmail();
        this.phone         = s.getPhone();
        this.grade         = s.getGrade();
        this.departmentId  = s.getDepartment() != null
                ? s.getDepartment().getId()
                : null;
        this.password      = s.getPassword();  // ← 이 줄도 같이 있으면 좋습니다
    }
}
