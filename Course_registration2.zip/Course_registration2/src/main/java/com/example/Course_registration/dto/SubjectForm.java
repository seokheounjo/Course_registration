// src/main/java/com/example/Course_registration/dto/SubjectForm.java
package com.example.Course_registration.dto;

import com.example.Course_registration.entity.subject.Subject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class SubjectForm {
    private Long    id;
    private String  name;
    private Integer credits;
    private Integer capacity;
    private String  semester;
    private String  schedule;
    private Integer gradeLimit;
    private Boolean required;
    private Long    professorId;
    private Long    departmentId;

    public SubjectForm(Subject s) {
        this.id          = s.getId();
        this.name        = s.getName();
        this.credits     = s.getCredits();
        this.capacity    = s.getCapacity();
        this.semester    = s.getSemester();
        this.schedule    = s.getSchedule();
        this.gradeLimit  = s.getGradeLimit();
        this.required    = s.getIsRequired();
        this.professorId = s.getProfessor()!=null ? s.getProfessor().getId() : null;
        this.departmentId= s.getDepartment()!=null? s.getDepartment().getId(): null;
    }
}
