package com.example.Course_registration.entity;

public class a {
}
