package com.example.Course_registration.entity.enrollment;

import com.example.Course_registration.entity.student.Student;
import com.example.Course_registration.entity.subject.Subject;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne
    @JoinColumn(name = "subject_id")
    private Subject subject;

    @Column(nullable = false)
    private String status; // 신청, 대기, 취소

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
}
