// src/main/java/com/example/Course_registration/entity/professor/Professor.java
package com.example.Course_registration.entity.professor;

import com.example.Course_registration.entity.department.Department;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Professor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ───────────────────────────────────────────
    // 고유 코드 필드 추가
    @Column(nullable = false, unique = true)
    private String professorCode;
    // ───────────────────────────────────────────

    @Column(nullable = false)
    private String name;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;
}
