// src/main/java/com/example/Course_registration/entity/student/Student.java
package com.example.Course_registration.entity.student;

import com.example.Course_registration.entity.department.Department;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String studentNumber;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    // ────────────────────────────────
    // 로그인용 비밀번호 필드
    @Column(nullable = false)
    private String password;
    // ────────────────────────────────

    private String phone;
    private Integer grade;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;
}
