package com.example.Course_registration.repository;

import com.example.Course_registration.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
    List<Schedule> findBySubjectId(Long subjectId);
}
