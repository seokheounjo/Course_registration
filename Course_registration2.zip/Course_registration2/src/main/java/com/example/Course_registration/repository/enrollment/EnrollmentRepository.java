package com.example.Course_registration.repository.enrollment;

import com.example.Course_registration.entity.enrollment.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentId(Long studentId);
    List<Enrollment> findBySubjectId(Long subjectId);
    boolean existsByStudentIdAndSubjectId(Long studentId, Long subjectId);
}
