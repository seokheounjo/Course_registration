package com.example.Course_registration.repository.notice;

import com.example.Course_registration.entity.notice.Notice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoticeRepository extends JpaRepository<Notice, Long> {
}
