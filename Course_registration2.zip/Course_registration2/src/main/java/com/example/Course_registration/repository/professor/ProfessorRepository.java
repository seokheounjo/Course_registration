package com.example.Course_registration.repository.professor;

import com.example.Course_registration.entity.professor.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProfessorRepository extends JpaRepository<Professor, Long> {
    List<Professor> findByDepartmentId(Long departmentId);
}
