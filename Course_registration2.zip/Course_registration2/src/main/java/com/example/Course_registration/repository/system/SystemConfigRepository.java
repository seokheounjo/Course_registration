package com.example.Course_registration.repository.system;

import com.example.Course_registration.entity.system.SystemConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemConfigRepository extends JpaRepository<SystemConfig, Long> {
    SystemConfig findTopByOrderByIdDesc(); // 최신 설정 1개 조회
}
