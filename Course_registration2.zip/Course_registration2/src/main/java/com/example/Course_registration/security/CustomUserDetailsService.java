// src/main/java/com/example/Course_registration/security/CustomUserDetailsService.java
package com.example.Course_registration.security;

import com.example.Course_registration.entity.admin.Admin;          // 예: 관리자 엔티티
import com.example.Course_registration.entity.student.Student;
import com.example.Course_registration.repository.admin.AdminRepository;
import com.example.Course_registration.repository.student.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final AdminRepository adminRepository;
    private final StudentRepository studentRepository;

    @Override
    public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
        // 1) 관리자 먼저 시도
        return adminRepository.findByUsername(loginId)
                .map(admin -> {
                    UserBuilder b = User.withUsername(admin.getUsername());
                    b.password(admin.getPassword())
                            .roles("ADMIN");
                    return b.build();
                })
                // 2) 관리자 없으면 학생에서 찾기
                .orElseGet(() -> {
                    Student s = studentRepository.findByEmail(loginId)
                            .orElseThrow(() -> new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + loginId));
                    UserBuilder b = User.withUsername(s.getEmail());
                    b.password(s.getPassword())
                            .roles("STUDENT");
                    return b.build();
                });
    }
}
