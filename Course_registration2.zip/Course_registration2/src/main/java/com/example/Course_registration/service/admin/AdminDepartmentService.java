package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.DepartmentForm;
import com.example.Course_registration.dto.Option;

import java.util.List;

public interface AdminDepartmentService {
    List<DepartmentForm> findAll();
    DepartmentForm findById(Long id);
    void create(DepartmentForm form);
    void update(Long id, DepartmentForm form);
    void delete(Long id);

    // ✅ 추가
    List<Option> listDepartmentsWithSelected(Long selectedId);
}
