// src/main/java/com/example/Course_registration/service/admin/AdminNoticeService.java
package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.NoticeForm;
import java.util.List;

public interface AdminNoticeService {
    List<NoticeForm> findAll();
    NoticeForm       findById(Long id);
    void             create(NoticeForm form);
    void             update(Long id, NoticeForm form);
    void             delete(Long id);
}
