package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.ProfessorForm;
import java.util.List;

public interface AdminProfessorService {
    List<ProfessorForm> findAll();
    ProfessorForm       findById(Long id);
    void                create(ProfessorForm f);
    void                update(Long id, ProfessorForm f);
    void                delete(Long id);
}
