package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.ScheduleForm;
import java.util.List;

public interface AdminScheduleService {
    List<ScheduleForm> findAll();
    void create(ScheduleForm form);
    ScheduleForm getForm(Long id);
    void update(Long id, ScheduleForm form);
    void delete(Long id);
}
