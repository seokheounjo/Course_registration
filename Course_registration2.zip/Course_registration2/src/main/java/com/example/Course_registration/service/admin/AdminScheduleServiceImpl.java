package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.ScheduleForm;
import com.example.Course_registration.entity.Schedule;
import com.example.Course_registration.repository.ScheduleRepository;
import com.example.Course_registration.repository.subject.SubjectRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminScheduleServiceImpl implements AdminScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final SubjectRepository subjectRepository;

    @Override
    public List<ScheduleForm> findAll() {
        return scheduleRepository.findAll().stream()
                .map(this::toForm)
                .collect(Collectors.toList());
    }

    @Override
    public void create(ScheduleForm form) {
        Schedule s = new Schedule();
        s.setDayOfWeek(form.getDayOfWeek());
        s.setStartTime(LocalTime.parse(form.getStartTime()));
        s.setEndTime(LocalTime.parse(form.getEndTime()));
        subjectRepository.findById(form.getSubjectId())
                .ifPresent(s::setSubject);
        scheduleRepository.save(s);
    }

    @Override
    public ScheduleForm getForm(Long id) {
        Schedule s = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 일정이 없습니다: " + id));
        return toForm(s);
    }

    @Override
    public void update(Long id, ScheduleForm form) {
        Schedule s = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 일정이 없습니다: " + id));
        s.setDayOfWeek(form.getDayOfWeek());
        s.setStartTime(LocalTime.parse(form.getStartTime()));
        s.setEndTime(LocalTime.parse(form.getEndTime()));
        subjectRepository.findById(form.getSubjectId())
                .ifPresent(s::setSubject);
        scheduleRepository.save(s);
    }

    @Override
    public void delete(Long id) {
        scheduleRepository.deleteById(id);
    }

    private ScheduleForm toForm(Schedule s) {
        ScheduleForm f = new ScheduleForm();
        f.setId(s.getId());
        f.setDayOfWeek(s.getDayOfWeek());
        f.setStartTime(s.getStartTime().toString());
        f.setEndTime(s.getEndTime().toString());
        f.setSubjectId(s.getSubject().getId());
        return f;
    }
}
