package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.SubjectForm;
import java.util.List;

public interface AdminService {
    List<SubjectForm> findAll();
    SubjectForm findById(Long id);
    void save(SubjectForm form);
    void update(Long id, SubjectForm form);
    void delete(Long id);
}
