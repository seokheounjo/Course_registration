// src/main/java/com/example/Course_registration/service/admin/AdminStudentService.java
package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.StudentForm;
import java.util.List;

public interface AdminStudentService {
    List<StudentForm> findAll();
    StudentForm       findById(Long id);
    void              create(StudentForm form);
    void              update(Long id, StudentForm form);
    void              delete(Long id);
}
