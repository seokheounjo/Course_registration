package com.example.Course_registration.service.admin;

import com.example.Course_registration.dto.Option;
import com.example.Course_registration.dto.SubjectForm;
import java.util.List;

public interface AdminSubjectService {
    List<SubjectForm> findAll();
    SubjectForm        getById(Long id);
    List<Option>       listProfessors();
    List<Option>       listDepartments();
    void               create(SubjectForm form);
    void               update(Long id, SubjectForm form);
    void               delete(Long id);
}
