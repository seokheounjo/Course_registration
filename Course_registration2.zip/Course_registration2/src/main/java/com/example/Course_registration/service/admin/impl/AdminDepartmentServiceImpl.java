package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.DepartmentForm;
import com.example.Course_registration.dto.Option;
import com.example.Course_registration.entity.department.Department;
import com.example.Course_registration.repository.department.DepartmentRepository;
import com.example.Course_registration.service.admin.AdminDepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminDepartmentServiceImpl implements AdminDepartmentService {

    private final DepartmentRepository deptRepo;

    @Override
    public List<DepartmentForm> findAll() {
        return deptRepo.findAll().stream()
                .map(DepartmentForm::new)
                .collect(Collectors.toList());
    }

    @Override
    public DepartmentForm findById(Long id) {
        Department d = deptRepo.findById(id).orElseThrow();
        return new DepartmentForm(d);
    }

    @Override
    public void create(DepartmentForm form) {
        Department d = new Department();
        d.setName(form.getName());
        deptRepo.save(d);
    }

    @Override
    public void update(Long id, DepartmentForm form) {
        Department d = deptRepo.findById(id).orElseThrow();
        d.setName(form.getName());
        deptRepo.save(d);
    }

    @Override
    public void delete(Long id) {
        deptRepo.deleteById(id);
    }

    // ✅ 여기에 추가된 메서드
    @Override
    public List<Option> listDepartmentsWithSelected(Long selectedId) {
        return deptRepo.findAll().stream()
                .map(dept -> new Option(
                        dept.getId(),
                        dept.getName(),
                        selectedId != null && dept.getId().equals(selectedId)
                ))
                .collect(Collectors.toList());
    }
}
