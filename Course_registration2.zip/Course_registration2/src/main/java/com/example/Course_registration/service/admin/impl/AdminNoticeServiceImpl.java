// src/main/java/com/example/Course_registration/service/admin/impl/AdminNoticeServiceImpl.java
package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.NoticeForm;
import com.example.Course_registration.entity.notice.Notice;
import com.example.Course_registration.repository.notice.NoticeRepository;
import com.example.Course_registration.service.admin.AdminNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminNoticeServiceImpl implements AdminNoticeService {
    private final NoticeRepository noticeRepo;

    @Override
    public List<NoticeForm> findAll() {
        return noticeRepo.findAll().stream()
                .map(NoticeForm::new)
                .collect(Collectors.toList());
    }

    @Override
    public NoticeForm findById(Long id) {
        return noticeRepo.findById(id)
                .map(NoticeForm::new)
                .orElseThrow(() -> new IllegalArgumentException("No such notice: " + id));
    }

    @Override
    public void create(NoticeForm f) {
        Notice n = new Notice();
        n.setTitle  (f.getTitle());
        n.setContent(f.getContent());
        noticeRepo.save(n);
    }

    @Override
    public void update(Long id, NoticeForm f) {
        Notice n = noticeRepo.getReferenceById(id);
        n.setTitle  (f.getTitle());
        n.setContent(f.getContent());
    }

    @Override
    public void delete(Long id) {
        noticeRepo.deleteById(id);
    }
}
