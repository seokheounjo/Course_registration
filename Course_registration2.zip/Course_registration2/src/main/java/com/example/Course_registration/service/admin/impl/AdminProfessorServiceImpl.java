package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.Option;
import com.example.Course_registration.dto.ProfessorForm;
import com.example.Course_registration.entity.department.Department;
import com.example.Course_registration.entity.professor.Professor;
import com.example.Course_registration.repository.department.DepartmentRepository;
import com.example.Course_registration.repository.professor.ProfessorRepository;
import com.example.Course_registration.service.admin.AdminProfessorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class AdminProfessorServiceImpl implements AdminProfessorService {

    private final ProfessorRepository   profRepo;
    private final DepartmentRepository  deptRepo;

    @Override public List<ProfessorForm> findAll() {
        return profRepo.findAll().stream().map(ProfessorForm::new).toList();
    }
    @Override public ProfessorForm findById(Long id) {
        return profRepo.findById(id).map(ProfessorForm::new)
                .orElseThrow(() -> new IllegalArgumentException("교수 없음: "+id));
    }
    @Override public void create(ProfessorForm f) {
        Professor p = new Professor();
        p.setProfessorCode(f.getProfessorCode());
        p.setName(f.getName());
        if (f.getDepartmentId()!=null)
            p.setDepartment(deptRepo.getReferenceById(f.getDepartmentId()));
        profRepo.save(p);
    }
    @Override public void update(Long id, ProfessorForm f) {
        Professor p = profRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("교수 없음: "+id));
        p.setProfessorCode(f.getProfessorCode());
        p.setName(f.getName());
        if (f.getDepartmentId()!=null)
            p.setDepartment(deptRepo.getReferenceById(f.getDepartmentId()));
    }
    @Override public void delete(Long id) { profRepo.deleteById(id); }
}