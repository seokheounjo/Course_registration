package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.SubjectForm;
import com.example.Course_registration.entity.subject.Subject;
import com.example.Course_registration.repository.subject.SubjectRepository;
import com.example.Course_registration.service.admin.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final SubjectRepository subjectRepository;

    @Override
    public List<SubjectForm> findAll() {
        return subjectRepository.findAll().stream()
                .map(SubjectForm::new)
                .collect(Collectors.toList());
    }

    @Override
    public SubjectForm findById(Long id) {
        return subjectRepository.findById(id)
                .map(SubjectForm::new)
                .orElseThrow(() -> new IllegalArgumentException("Subject not found: " + id));
    }

    @Override
    public void save(SubjectForm form) {
        subjectRepository.save(toEntity(form));
    }

    @Override
    public void update(Long id, SubjectForm form) {
        form.setId(id);
        subjectRepository.save(toEntity(form));
    }

    @Override
    public void delete(Long id) {
        subjectRepository.deleteById(id);
    }

    // ── Form ↔ Entity 변환 ─────────────────────────────
    private SubjectForm toForm(Subject s) {
        SubjectForm f = new SubjectForm(s);
        // 생성자에서 이미 모든 필드를 세팅하도록 했습니다.
        return f;
    }

    private Subject toEntity(SubjectForm f) {
        Subject s = new Subject();
        s.setId(f.getId());
        s.setName(f.getName());
        s.setCredits(f.getCredits());
        s.setCapacity(f.getCapacity());
        s.setSemester(f.getSemester());

        s.setSchedule   (f.getSchedule());
        s.setGradeLimit (f.getGradeLimit());
        s.setIsRequired (f.getRequired());

        // 교수/학과 연관관계 설정이 필요하면 여기에 추가
        return s;
    }
}
