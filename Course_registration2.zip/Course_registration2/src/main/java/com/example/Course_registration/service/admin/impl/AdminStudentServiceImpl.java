// src/main/java/com/example/Course_registration/service/admin/impl/AdminStudentServiceImpl.java
package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.StudentForm;
import com.example.Course_registration.entity.student.Student;
import com.example.Course_registration.repository.department.DepartmentRepository;
import com.example.Course_registration.repository.student.StudentRepository;
import com.example.Course_registration.service.admin.AdminStudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminStudentServiceImpl implements AdminStudentService {

    private final StudentRepository    studentRepo;
    private final DepartmentRepository deptRepo;

    @Override
    public List<StudentForm> findAll() {
        return studentRepo.findAll()
                .stream()
                .map(StudentForm::new)
                .toList();
    }

    @Override
    public StudentForm findById(Long id) {
        return studentRepo.findById(id)
                .map(StudentForm::new)
                .orElseThrow(() -> new IllegalArgumentException("학생 없음: " + id));
    }

    @Override
    public void create(StudentForm f) {
        Student s = new Student();
        s.setStudentNumber(f.getStudentNumber());
        s.setName(f.getName());
        s.setEmail(f.getEmail());
        s.setPhone(f.getPhone());
        s.setGrade(f.getGrade());
        s.setPassword(f.getPassword()); // ← 반드시 있어야 로그인 가능
        if (f.getDepartmentId() != null) {
            s.setDepartment(deptRepo.getReferenceById(f.getDepartmentId()));
        }
        studentRepo.save(s);
    }

    @Override
    public void update(Long id, StudentForm f) {
        Student s = studentRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("학생 없음: " + id));
        s.setStudentNumber(f.getStudentNumber());
        s.setName(f.getName());
        s.setEmail(f.getEmail());
        s.setPhone(f.getPhone());
        s.setGrade(f.getGrade());
        if (f.getDepartmentId()!=null) {
            s.setDepartment(deptRepo.getReferenceById(f.getDepartmentId()));
        }
        studentRepo.save(s);
    }

    @Override
    public void delete(Long id) {
        studentRepo.deleteById(id);
    }
}
