package com.example.Course_registration.service.admin.impl;

import com.example.Course_registration.dto.Option;
import com.example.Course_registration.dto.SubjectForm;
import com.example.Course_registration.entity.department.Department;
import com.example.Course_registration.entity.professor.Professor;
import com.example.Course_registration.entity.subject.Subject;
import com.example.Course_registration.repository.department.DepartmentRepository;
import com.example.Course_registration.repository.professor.ProfessorRepository;
import com.example.Course_registration.repository.subject.SubjectRepository;
import com.example.Course_registration.service.admin.AdminSubjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminSubjectServiceImpl implements AdminSubjectService {

    private final SubjectRepository     subjectRepo;
    private final ProfessorRepository   profRepo;
    private final DepartmentRepository  deptRepo;

    @Override
    public List<SubjectForm> findAll() {
        return subjectRepo.findAll().stream()
                .map(SubjectForm::new)
                .collect(Collectors.toList());
    }

    @Override
    public SubjectForm getById(Long id) {
        Subject subj = subjectRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("과목을 찾을 수 없습니다: " + id));
        return new SubjectForm(subj);
    }

    @Override
    public List<Option> listProfessors() {
        return profRepo.findAll().stream()
                .map(prof -> new Option(prof.getId(), prof.getName(), false))
                .collect(Collectors.toList());
    }

    @Override
    public List<Option> listDepartments() {
        return deptRepo.findAll().stream()
                .map(dept -> new Option(dept.getId(), dept.getName(), false))
                .collect(Collectors.toList());
    }

    @Override
    public void create(SubjectForm form) {
        Professor p = profRepo.findById(form.getProfessorId())
                .orElseThrow(() -> new IllegalArgumentException("교수를 찾을 수 없습니다: " + form.getProfessorId()));
        Department d = deptRepo.findById(form.getDepartmentId())
                .orElseThrow(() -> new IllegalArgumentException("학과를 찾을 수 없습니다: " + form.getDepartmentId()));
        Subject subj = new Subject();
        subj.setName(form.getName());
        subj.setCredits(form.getCredits());
        subj.setCapacity(form.getCapacity());
        subj.setSemester(form.getSemester());
        subj.setProfessor(p);
        subj.setDepartment(d);
        subjectRepo.save(subj);
    }

    @Override
    public void update(Long id, SubjectForm form) {
        Subject subj = subjectRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("과목을 찾을 수 없습니다: " + id));
        Professor p = profRepo.findById(form.getProfessorId())
                .orElseThrow(() -> new IllegalArgumentException("교수를 찾을 수 없습니다: " + form.getProfessorId()));
        Department d = deptRepo.findById(form.getDepartmentId())
                .orElseThrow(() -> new IllegalArgumentException("학과를 찾을 수 없습니다: " + form.getDepartmentId()));
        subj.setName(form.getName());
        subj.setCredits(form.getCredits());
        subj.setCapacity(form.getCapacity());
        subj.setSemester(form.getSemester());
        subj.setProfessor(p);
        subj.setDepartment(d);
        subjectRepo.save(subj);
    }

    @Override
    public void delete(Long id) {
        subjectRepo.deleteById(id);
    }
}
