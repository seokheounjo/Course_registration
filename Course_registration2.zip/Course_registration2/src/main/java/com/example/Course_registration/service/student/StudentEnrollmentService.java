package com.example.Course_registration.service.student;

import com.example.Course_registration.entity.enrollment.Enrollment;
import com.example.Course_registration.entity.student.Student;
import com.example.Course_registration.entity.subject.Subject;
import com.example.Course_registration.repository.enrollment.EnrollmentRepository;
import com.example.Course_registration.repository.student.StudentRepository;
import com.example.Course_registration.repository.subject.SubjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentEnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;

    public List<Enrollment> findByStudentEmail(String email) {
        Student student = studentRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("학생 없음: " + email));
        return enrollmentRepository.findByStudentId(student.getId());
    }

    public void enroll(String email, Long subjectId) {
        Student student = studentRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("학생 없음: " + email));
        Subject subject = subjectRepository.findById(subjectId)
                .orElseThrow(() -> new IllegalArgumentException("과목 없음: " + subjectId));

        boolean alreadyExists = enrollmentRepository.existsByStudentIdAndSubjectId(student.getId(), subjectId);
        if (alreadyExists) return;

        Enrollment enrollment = Enrollment.builder()
                .student(student)
                .subject(subject)
                .status("신청")
                .build();
        enrollmentRepository.save(enrollment);
    }

    public void cancel(String email, Long subjectId) {
        Student student = studentRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("학생 없음: " + email));
        List<Enrollment> enrollments = enrollmentRepository.findByStudentId(student.getId());
        enrollments.stream()
                .filter(e -> e.getSubject().getId().equals(subjectId))
                .findFirst()
                .ifPresent(enrollmentRepository::delete);
    }
}
